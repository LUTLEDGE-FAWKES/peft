import logging
import os
from dataclasses import dataclass, field
from typing import Optional, Dict

import torch
import transformers
from peft import prepare_model_for_kbit_training, PeftModelForSeq2SeqLM
from transformers import MODEL_FOR_CAUSAL_LM_MAPPING, AutoConfig, CONFIG_MAPPING, AutoTokenizer, AutoModelForCausalLM, \
    AutoModelForSequenceClassification, AutoModelForSeq2SeqLM
from peft import TaskType
from peft import LoraConfig, AdaLoraConfig
from peft import PeftModelForCausalLM, PeftModelForSequenceClassification
# from peft.mapping import TRANSFORMERS_MODELS_TO_LORA_TARGET_MODULES_MAPPING
from peft.utils import TRANSFORMERS_MODELS_TO_LORA_TARGET_MODULES_MAPPING

T5_MODEL_TYPES = ['t5','mt5']

logger = logging.getLogger(__name__)

MODEL_CONFIG_CLASSES = list(MODEL_FOR_CAUSAL_LM_MAPPING.keys())
MODEL_TYPES = tuple(conf.model_type for conf in MODEL_CONFIG_CLASSES)

DEFAULT_PAD_TOKEN = "[PAD]"
DEFAULT_EOS_TOKEN = "</s>"
DEFAULT_BOS_TOKEN = "</s>"
DEFAULT_UNK_TOKEN = "</s>"


@dataclass
class ModelArguments:
    """
    Arguments pertaining to which model/config/tokenizer we are going to fine-tune, or train from scratch.
    """

    model_name_or_path: Optional[str] = field(
        default=None,
        metadata={
            "help": (
                "The model checkpoint for weights initialization.Don't set if you want to train a model from scratch."
            )
        },
    )
    model_type: Optional[str] = field(
        default=None,
        metadata={"help": "If training from scratch, pass a model type from the list: " + ", ".join(MODEL_TYPES)},
    )
    config_overrides: Optional[str] = field(
        default=None,
        metadata={
            "help": (
                "Override some existing default config settings when a model is trained from scratch. Example: "
                "n_embd=10,resid_pdrop=0.2,scale_attn_weights=false,summary_type=cls_index"
            )
        },
    )
    config_name: Optional[str] = field(
        default=None, metadata={"help": "Pretrained config name or path if not the same as model_name"}
    )
    tokenizer_name: Optional[str] = field(
        default=None, metadata={"help": "Pretrained tokenizer name or path if not the same as model_name"}
    )
    cache_dir: Optional[str] = field(
        default=None,
        metadata={"help": "Where do you want to store the pretrained models downloaded from huggingface.co"},
    )
    use_fast_tokenizer: bool = field(
        default=True,
        metadata={"help": "Whether to use one of the fast tokenizer (backed by the tokenizers library) or not."},
    )
    model_revision: str = field(
        default="main",
        metadata={"help": "The specific model version to use (can be a branch name, tag name or commit id)."},
    )
    token: str = field(
        default=None,
        metadata={
            "help": (
                "The token to use as HTTP bearer authorization for remote files. If not specified, will use the token "
                "generated when running `huggingface-cli login` (stored in `~/.huggingface`)."
            )
        },
    )
    use_auth_token: bool = field(
        default=False,
        metadata={
            "help": (
                "Will use the token generated when running `huggingface-cli login` (necessary to use this script "
                "with private models)."
            )
        },
    )
    load_in_8bit: bool = field(
        default=False,
        metadata={"help": "Whether to load the model in 8-bit precision (fp16)."},
    )
    load_in_cuda: bool = field(
        default=False,
        metadata={"help": "Whether to load the model in CUDA."},
    )
    load_in_dist: bool = field(
        default=False,
        metadata={"help": "Whether to load the model in distributed mode."},
    )
    torch_dtype: Optional[str] = field(
        default=None,
        metadata={
            "help": (
                "Override the default `torch.dtype` and load the model under this dtype. If `auto` is passed, the "
                "dtype will be automatically derived from the model's weights."
            ),
            "choices": ["auto", "bfloat16", "float16", "float32"],
        },
    )
    model_compile: bool = field(
        default=False,
        metadata={"help": "Whether to compile the model with PyTorch 2.0."},
    )

    lora: bool = field(
        default=False,
        metadata={"help": "Whether to use LORA."},
    )
    adalora: bool = field(
        default=False,
        metadata={"help": "Whether to use AdaLoRA."},
    )
    lora_config: str = field(
        default="",
        metadata={"help": "LORA config path."},
    )
    lora_r: int = field(
        default=8,
        metadata={"help": "LORA r."},
    )
    lora_target_modules: str = field(
        default=None,
        metadata={"help": "LORA target modules."},
    )
    lora_alpha: int = field(
        default=32,
        metadata={"help": "LORA alpha."},
    )
    lora_dropout: float = field(
        default=0.1,
        metadata={"help": "LORA dropout."},
    )
    trust_remote_code: bool = field(
        default=False,
        metadata={
            "help": (
                "Whether or not to allow for custom models defined on the Hub in their own modeling files. This option"
                "should only be set to `True` for repositories you trust and in which you have read the code, as it will "
                "execute code present on the Hub on your local machine."
            )
        },
    )

    # def ___init__(self):
    #     if self.config_overrides is not None and (self.config_name is not None or self.model_name_or_path is not None):
    #         raise ValueError(
    #             "--config_overrides can't be used in combination with --config_name or --model_name_or_path"
    #         )
    def __post_init__(self):
        if self.config_overrides is not None and (self.config_name is not None or self.model_name_or_path is not None):
            raise ValueError(
                "--config_overrides can't be used in combination with --config_name or --model_name_or_path"
            )
        if isinstance(self.lora_target_modules,str):
            self.lora_target_modules = self.lora_target_modules.split(',')
        if isinstance(self.lora_target_modules,tuple):
            self.lora_target_modules = tuple('.'+param for param in self.lora_target_modules)
        if self.lora and self.adalora:
            raise ValueError(
                "--lora and --adalora can't be used together"
            )


def smart_tokenizer_and_embedding_resize(
        special_tokens_dict: Dict,
        tokenizer: transformers.PreTrainedTokenizer,
        model: transformers.PreTrainedModel,
):
    """Resize tokenizer and embedding.

    Note: This is the unoptimized version that may make your embedding size not be divisible by 64.
    """
    num_new_tokens = tokenizer.add_special_tokens(special_tokens_dict)
    model.resize_token_embeddings(len(tokenizer))

    if num_new_tokens > 0:
        input_embeddings = model.get_input_embeddings().weight.data
        input_embeddings_avg = input_embeddings[:-num_new_tokens].mean(dim=0, keepdim=True)
        input_embeddings[-num_new_tokens:] = input_embeddings_avg
        if model.get_output_embeddings():
            output_embeddings = model.get_output_embeddings().weight.data
            output_embeddings_avg = output_embeddings[:-num_new_tokens].mean(dim=0, keepdim=True)
            output_embeddings[-num_new_tokens:] = output_embeddings_avg


def load_model(task, model_args, local_dir, gradient_checkpointing=False, tokenizer_only=False):
    # Load pretrained model and tokenizer
    #
    # Distributed training:
    # The .from_pretrained methods guarantee that only one local process can concurrently
    # download model & vocab.

    config_kwargs = {
        "cache_dir": local_dir,
        "revision": model_args.model_revision,
        "trust_remote_code": True,
        "use_auth_token": True if model_args.use_auth_token else None,
    }
    if gradient_checkpointing:
        config_kwargs["gradient_checkpointing"] = True
        config_kwargs["use_cache"] = False
    if model_args.config_name:
        config = AutoConfig.from_pretrained(model_args.config_name, **config_kwargs)
    elif model_args.model_name_or_path:
        config = AutoConfig.from_pretrained(model_args.model_name_or_path, **config_kwargs)
    else:
        config = CONFIG_MAPPING[model_args.model_type]()
        logger.warning("You are instantiating a new config instance from scratch.")
        if model_args.config_overrides is not None:
            logger.info(f"Overriding config: {model_args.config_overrides}")
            config.update_from_string(model_args.config_overrides)
            logger.info(f"New config: {config}")

    tokenizer_kwargs = {
        "cache_dir": local_dir,
        "use_fast": model_args.use_fast_tokenizer,
        "revision": model_args.model_revision,
        "trust_remote_code": True,
        "use_auth_token": True if model_args.use_auth_token else None,
    }
    if model_args.tokenizer_name:
        tokenizer = AutoTokenizer.from_pretrained(model_args.tokenizer_name, **tokenizer_kwargs)
    elif model_args.model_name_or_path:
        tokenizer = AutoTokenizer.from_pretrained(model_args.model_name_or_path, **tokenizer_kwargs)
    else:
        raise ValueError(
            "You are instantiating a new tokenizer from scratch. This is not supported by this script."
            "You can do it from another script, save it, and load it from here, using --tokenizer_name."
        )

    if task == "lm": # **task相关
        AutoModel = AutoModelForCausalLM
        task_type = TaskType.CAUSAL_LM
        PeftModel = PeftModelForCausalLM
        if config.model_type in T5_MODEL_TYPES:
            AutoModel = AutoModelForSeq2SeqLM
            task_type = TaskType.SEQ_2_SEQ_LM
            PeftModel = PeftModelForSeq2SeqLM
    # elif task == "reg":
    #     AutoModel = AutoModelForSequenceClassification
    #     task_type = TaskType.SEQ_CLS
    #     PeftModel = PeftModelForSequenceClassification
    #     config.num_labels = 1
    # elif task == "clf":
    #     AutoModel = BertForSequenceClassification
    #     task_type = TaskType.SEQ_CLS
    #     PeftModel = PeftModelForSequenceClassification
    #     config.num_labels = 5
    else:
        raise NotImplementedError(f"task {task} not implemented")

    if model_args.model_name_or_path:
        torch_dtype = (
            model_args.torch_dtype
            if model_args.torch_dtype in ["auto", None]
            else getattr(torch, model_args.torch_dtype)
        )
        args_extra = dict()
        if model_args.load_in_8bit:
            # args_extra["device_map"] = 'auto'
            args_extra["device_map"] = {"": int(os.environ.get("LOCAL_RANK", "0"))}
            args_extra["load_in_8bit"] = model_args.load_in_8bit
            # config.use_cache = False

        if model_args.load_in_cuda:
            args_extra["device_map"] = {"": int(os.environ.get("LOCAL_RANK", "0"))}

        if model_args.load_in_dist:
            args_extra["device_map"] = "auto" # 自动分布在多个gpu上

        model = AutoModel.from_pretrained( # **task相关
            model_args.model_name_or_path,
            from_tf=bool(".ckpt" in model_args.model_name_or_path),
            config=config,
            cache_dir=local_dir,
            revision=model_args.model_revision,
            use_auth_token=True if model_args.use_auth_token else None,
            torch_dtype=torch_dtype,
            trust_remote_code=True,
            low_cpu_mem_usage=True,
            **args_extra,
        )
    else:
        model = AutoModel.from_config(config)
        n_params = sum(dict((p.data_ptr(), p.numel()) for p in model.parameters()).values())
        logger.info(f"Training new model from scratch - Total size={n_params / 2 ** 20:.2f}M params")

    if model_args.lora or model_args.adalora:
        if model_args.lora_config:
            peft_config = LoraConfig.from_json_file(model_args.lora_config)
        else:
            lora_config = dict(r=model_args.lora_r,
            lora_alpha=model_args.lora_alpha,
            lora_dropout=model_args.lora_dropout,
            task_type=task_type, # **task相关
            target_modules=model_args.lora_target_modules,
            inference_mode=False,
            # enable_lora=None, # TODO: 目前只能设置为None，否则会创建Conv1D，导致导出报错
            bias="none",
            fan_in_fan_out=False)

            if model_args.lora:
                peft_config = LoraConfig(peft_type="LORA", **lora_config)
            if model_args.adalora:
                peft_config = AdaLoraConfig(peft_type="ADALORA", **lora_config)
            
            if peft_config.target_modules is None:
                if config.model_type not in TRANSFORMERS_MODELS_TO_LORA_TARGET_MODULES_MAPPING:
                    raise ValueError("Please specify `target_modules` in `peft_config`")
                peft_config.target_modules = TRANSFORMERS_MODELS_TO_LORA_TARGET_MODULES_MAPPING[config.model_type]
        # model = get_peft_model(model, peft_config)
        # model = LoraModel(config=peft_config, model=model)
        model = PeftModel(model=model, peft_config=peft_config) # **task相关
        print("lora_test_llm_model.py:")
        model.print_trainable_parameters()
        print("-=-=-")

    # We resize the embeddings only when necessary to avoid index errors. If you are creating a model from scratch
    # on a small vocab and want a smaller embedding size, remove this test.
    if config.model_type == 'llama':
        # 参考
        # https://github.com/tloen/alpaca-lora/issues/279
        # https://huggingface.co/yahma/llama-7b-hf
        model.config.unk_token_id = tokenizer.unk_token_id = 0
        model.config.bos_token_id = tokenizer.bos_token_id = 1
        model.config.eos_token_id = tokenizer.eos_token_id = 2
        tokenizer.unk_token = "<unk>"
        tokenizer.bos_token = "<s>"
        tokenizer.eos_token = "</s>"
        if tokenizer.pad_token is None:
            # model.config.pad_token_id = tokenizer.pad_token_id = tokenizer.bos_token_id
            # tokenizer.pad_token = tokenizer.bos_token
            model.config.pad_token_id = tokenizer.pad_token_id = tokenizer.unk_token_id
            tokenizer.pad_token = "<pad>"
    else:
        if tokenizer.pad_token is None:
            print(f"{model_args.model_name_or_path}, pad_token is None")
            if config.model_type == 'gpt2':
                tokenizer.pad_token = tokenizer.bos_token
                model.config.pad_token_id = tokenizer.pad_token_id = tokenizer.bos_token_id
            else:
                smart_tokenizer_and_embedding_resize(
                    special_tokens_dict=dict(pad_token=DEFAULT_PAD_TOKEN),
                    tokenizer=tokenizer,
                    model=model,
                )
                model.config.pad_token_id = tokenizer.pad_token_id

        if tokenizer.eos_token is None:
            print(f"{model_args.model_name_or_path}, eos_token is None")
            smart_tokenizer_and_embedding_resize(
                special_tokens_dict=dict(eos_token=DEFAULT_EOS_TOKEN),
                tokenizer=tokenizer,
                model=model,
            )
            model.config.eos_token_id = tokenizer.eos_token_id

        if tokenizer.bos_token is None:
            print(f"{model_args.model_name_or_path}, bos_token is None")
            new_token_dict = dict(bos_token=DEFAULT_BOS_TOKEN)
            # if 'chatyuan' in model_args.model_name_or_path.lower():
            #     new_token_dict = dict(bos_token='[s]')
            smart_tokenizer_and_embedding_resize(
                special_tokens_dict=new_token_dict,
                tokenizer=tokenizer,
                model=model,
            )
            model.config.bos_token_id = tokenizer.bos_token_id

        if tokenizer.unk_token is None:
            print(f"{model_args.model_name_or_path}, unk_token is None")
            smart_tokenizer_and_embedding_resize(
                special_tokens_dict=dict(unk_token=DEFAULT_UNK_TOKEN),
                tokenizer=tokenizer,
                model=model,
            )
            model.config.unk_token_id = tokenizer.unk_token_id

    # embedding_size = model.get_input_embeddings().weight.shape[0]
    # if len(tokenizer) > embedding_size: # 因为lora不调整embeddings, 所以不适合resize embeddings
    #     print(f"{model_args.model_name_or_path}, len(tokenizer) > embedding_size", len(tokenizer), embedding_size)
    #     model.resize_token_embeddings(len(tokenizer))

    if model_args.model_compile:
        model = torch.compile(model)

    if tokenizer_only:
            return tokenizer

    return model, tokenizer
